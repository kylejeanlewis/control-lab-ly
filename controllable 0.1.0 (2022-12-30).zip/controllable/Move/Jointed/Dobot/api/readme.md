Official API from Dobot's GitHub page
https://github.com/Dobot-Arm/TCP-IP-4Axis-Python 
