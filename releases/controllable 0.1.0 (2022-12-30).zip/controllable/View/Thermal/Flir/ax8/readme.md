Library to control the FLIR AX-8 Thermal Camera using its Modbus interface

Written By : Sharath (IMRE Singapore)
Date       : 23-07-2021