from .circuit_datatype import CircuitDiagram
from .eis_datatype import ImpedanceSpectrum

TYPES = [CircuitDiagram, ImpedanceSpectrum]
TYPE_NAMES = [_type.__name__ for _type in TYPES]